
document.addEventListener('deviceready', onDeviceReady, false);

function onDeviceReady() {

    console.log('Running cordova-' + cordova.platformId + '@' + cordova.version);
    document.getElementById('deviceready').classList.add('ready');
    navigator.geolocation.getCurrentPosition(
        onGeolocationSucess,
        onGeolocationError,
        geolocationOptions);
}

function onGeolocationSucess(position){
    alert('Latitude: '          + position.coords.latitude          + '\n' +
          'Longitude: '         + position.coords.longitude         + '\n' +
          'Altitude: '          + position.coords.altitude          + '\n' +
          'Accuracy: '          + position.coords.accuracy          + '\n' +
          'Altitude Accuracy: ' + position.coords.altitudeAccuracy  + '\n' +
          'Heading: '           + position.coords.heading           + '\n' +
          'Speed: '             + position.coords.speed             + '\n' +
          'Timestamp: '         + position.timestamp                + '\n');
}

function onGeolocationError(Error){
    alert('code:' + error.code + '\n' +
    'message:' + error.message + '\n');

}

geolocationOptions = {
    maximumAge: 3000,
    timeout: 5000,
    enableHighAccuracy: true
}